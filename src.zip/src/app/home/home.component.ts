import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  imagePath: string = "../assets/download.jpg";
  topText: string = "This is top text";
    bottomText: string = "This is bottom text";
    imageName: string = "Surprised Pikachu";
    colorName: string = "black";

    /*Note: In the event that new memes are to be added,
    the meme names and corresponding file-names need to be in the same order in both arrays.*/ 
    
    //stores names of all the memes
    imageNameList: string[] = ["Surprised Pikachu", "Crying Pepe", "Denerys"];
    //stores file-names of all memes
    imageFileNameList: string[] = ["download.jpg", "crying_pepe.jpg", "denerys.png"];


    changeImage(){
        var valueOfSearch: string = "";
        for(var i = 0; i < this.imageNameList.length; i++){
            if(this.imageNameList[i] === this.imageName){
                valueOfSearch = this.imageFileNameList[i];
            }
        }
        //console.log(valueOfSearch);
        //console.log(this.imageName);
        var whole: string = "assets/" + valueOfSearch;
        return whole;
    }

}
